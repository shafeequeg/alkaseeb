<div id="m_header_menu" class="m-header-menu m-aside-header-menu-mobile m-aside-header-menu-mobile--offcanvas  m-header-menu--skin-dark m-header-menu--submenu-skin-light m-aside-header-menu-mobile--skin-light m-aside-header-menu-mobile--submenu-skin-light "  >
    <ul class="m-menu__nav  m-menu__nav--submenu-arrow ">


        <li id="menu_article" class="m-menu__item  m-menu__item--submenu m-menu__item--rel"  aria-haspopup="true">
            <a  href="<?php echo base_url().$user_directory.'dashboard'?>" class="m-menu__link m-menu__toggle">
                <span class="m-menu__item-here"></span>
                <span class="m-menu__link-text">
                                                    Dashboard
                                                </span>
            </a>

        </li>
       
         
      
         
        <li id="menu_experts" class="m-menu__item  m-menu__item--submenu m-menu__item--rel"  data-menu-submenu-toggle="click" aria-haspopup="true">
            <a  href="#" class="m-menu__link m-menu__toggle">
                <span class="m-menu__item-here"></span>
                <span class="m-menu__link-text">
													Category
												</span>
                <i class="m-menu__hor-arrow la la-angle-down"></i>
                <i class="m-menu__ver-arrow la la-angle-right"></i>
            </a>
            <div class="m-menu__submenu m-menu__submenu--classic m-menu__submenu--left">
                <span class="m-menu__arrow m-menu__arrow--adjust"></span>
                <ul class="m-menu__subnav">
                    <li id="menu_experts_1" class="m-menu__item "  aria-haspopup="true">
                        <a  href="<?php echo base_url().$user_directory.'category'?>" class="m-menu__link ">
                            <i class="m-menu__link-icon fa fa-plus-square-o"></i>
                            <span class="m-menu__link-title">
                                <span class="m-menu__link-wrap">
                                    <span class="m-menu__link-text">
                                        Manage 
                                    </span>
                                </span>
                            </span>
                        </a>
                    </li>
                    
              
                </ul>
            </div>
            
        </li>
        
        <li id="menu_projects" class="m-menu__item  m-menu__item--submenu m-menu__item--rel"  data-menu-submenu-toggle="click" aria-haspopup="true">
            <a  href="#" class="m-menu__link m-menu__toggle">
                <span class="m-menu__item-here"></span>
                <span class="m-menu__link-text">
													Portfolio
												</span>
                <i class="m-menu__hor-arrow la la-angle-down"></i>
                <i class="m-menu__ver-arrow la la-angle-right"></i>
            </a>
            <div class="m-menu__submenu m-menu__submenu--classic m-menu__submenu--left">
                <span class="m-menu__arrow m-menu__arrow--adjust"></span>
                <ul class="m-menu__subnav">
                    <li id="menu_p_1" class="m-menu__item "  aria-haspopup="true">
                        <a  href="<?php echo base_url().$user_directory.'portfolio'?>" class="m-menu__link ">
                            <i class="m-menu__link-icon fa fa-plus-square-o"></i>
                            <span class="m-menu__link-title">
                                <span class="m-menu__link-wrap">
                                    <span class="m-menu__link-text">
                                        Manage 
                                    </span>
                                </span>
                            </span>
                        </a>
                    </li>
                   
                    
                </ul>
            </div>
            
        </li>
        <li id="menu_projects" class="m-menu__item  m-menu__item--submenu m-menu__item--rel"  data-menu-submenu-toggle="click" aria-haspopup="true">
            <a  href="#" class="m-menu__link m-menu__toggle">
                <span class="m-menu__item-here"></span>
                <span class="m-menu__link-text">
													Home Banner
												</span>
                <i class="m-menu__hor-arrow la la-angle-down"></i>
                <i class="m-menu__ver-arrow la la-angle-right"></i>
            </a>
            <div class="m-menu__submenu m-menu__submenu--classic m-menu__submenu--left">
                <span class="m-menu__arrow m-menu__arrow--adjust"></span>
                <ul class="m-menu__subnav">
                    <li id="menu_p_1" class="m-menu__item "  aria-haspopup="true">
                        <a  href="<?php echo base_url().$user_directory.'home'?>" class="m-menu__link ">
                            <i class="m-menu__link-icon fa fa-plus-square-o"></i>
                            <span class="m-menu__link-title">
                                <span class="m-menu__link-wrap">
                                    <span class="m-menu__link-text">
                                        Manage 
                                    </span>
                                </span>
                            </span>
                        </a>
                    </li>
                   
                    
                </ul>
            </div>
            
        </li>
       



        
        
    </ul>
</div>